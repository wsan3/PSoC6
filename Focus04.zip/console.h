/*
 * console.h
 *
 *  Created on: Jan 21, 2022
 *      Author: Joe Krachey
 */

#ifndef CONSOLE_H_
#define CONSOLE_H_

#include "cy_pdl.h"
#include "cyhal.h"
#include "cybsp.h"
#include "cy_retarget_io.h"


/* ADD CODE */
#define PIN_CONSOLE_TX 	P5_1
#define PIN_CONSOLE_RX	P5_0
#define BAUD_RATE		115200

#define DEBUG_MESSAGE_MAX_LEN   (100u)
#define INT_PRIORITY_CONSOLE	3

/* GLOBAL VARIABLES */
extern volatile bool ALERT_RX_CONSOLE;
extern int charIndex;
extern char inputString[];


/* Public Function API */
void console_init(void);


#endif /* CONSOLE_H_ */
