/*
 * console.c
 *
 */

#include "console.h"
// UART RETARGET IO OBJECT
extern cyhal_uart_t cy_retarget_io_uart_obj;
// Initialize global variables
volatile bool ALERT_RX_CONSOLE = false;
int charIndex = 0;
int numBackspaces = 0;
char inputString[DEBUG_MESSAGE_MAX_LEN];

/*******************************************************************************
 * Function Name: console_event_handler
 ********************************************************************************
 * Summary:
 * UART Handler used to receive characters from the console.
 *
 * Parameters:
 *  void
 *
 * Return:
 *
 *
 *******************************************************************************/
void console_event_handler(void *handler_arg, cyhal_uart_event_t event) {
	(void) handler_arg;
	cy_rslt_t rslt; // Result object to check

	int val; // ASCII value of current char
	char charIn; // current char

	if ((event & CYHAL_UART_IRQ_TX_ERROR) == CYHAL_UART_IRQ_TX_ERROR) {
		/* An error occurred in Tx */
		/* Insert application code to handle Tx error */
	} else if ((event & CYHAL_UART_IRQ_RX_NOT_EMPTY)
			== CYHAL_UART_IRQ_RX_NOT_EMPTY) {
		// RX not empty, character recieved
		rslt = cyhal_uart_getc(&cy_retarget_io_uart_obj, &val, 0);

		charIn = (char) val; // Convert to char

		// Check for success
		if (rslt == CY_RSLT_SUCCESS) {
			// If char received is a newline or return
			// Set signal to true
			if ((charIn == '\r') || (charIn == '\n')) {
				ALERT_RX_CONSOLE = true;
			} else {
				// Check for BACKSPACE
				if (charIn == '\b' || charIn == 127 || charIn == 8) {
					// Handle backspace and deletions
					if (val == 127 || charIndex == 0) {
						// Ignore consecutive backspace characters at the beginning or end of the inputString array
						numBackspaces = 0;
						return;
					} else {
						// Increment the number of consecutive backspace chars
						numBackspaces++;
						// Remove the corresponding number of chars
						inputString[charIndex - numBackspaces] = 0;
					}
				} else {
					// Reset number of backspaces
					numBackspaces = 0;
					// Add char to string
					inputString[charIndex++] = charIn;
				}

			}
		}
	}
}

/*******************************************************************************
 * Function Name: console_init_irq
 ********************************************************************************
 * Summary:
 * Enables and Registers all interrupt sources for the ECE453 Base project
 *
 * Parameters:
 *  void
 *
 * Return:
 *
 *
 *******************************************************************************/
static void console_init_irq(void) {
	// Enable Console Rx Interrupts
	/* The UART callback handler registration */
	cyhal_uart_register_callback(&cy_retarget_io_uart_obj,
			console_event_handler, NULL);

	/* Enable required UART events */
	cyhal_uart_enable_event(&cy_retarget_io_uart_obj,
			(cyhal_uart_event_t) (CYHAL_UART_IRQ_RX_NOT_EMPTY),
			INT_PRIORITY_CONSOLE, true);

}

/*******************************************************************************
 * Set up the console retarget IO
 *******************************************************************************/
static void console_init_retarget(void) {
	/* Initialize retarget-io to use the debug UART port, 8N1 */
	cy_retarget_io_init( PIN_CONSOLE_TX, PIN_CONSOLE_RX, BAUD_RATE);
}

/*******************************************************************************
 * Function Name: console_init
 ********************************************************************************
 * Summary:
 * 	Enables the SCB used for console interface.  Rx interrupts are turned on
 *
 * Parameters:
 *  void
 *
 * Return:
 *
 *
 *******************************************************************************/
void console_init(void) {
	console_init_retarget();
	console_init_irq();
}

